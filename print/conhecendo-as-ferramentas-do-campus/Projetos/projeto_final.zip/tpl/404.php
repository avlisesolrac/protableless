<title>404 | Pro Tableless - Agência web</title>
<meta name="description" content="404 | Pro Tableless - Desenvolvimento de sites nos padrões web, Trabalhando para você conquistar novos clientes" />
<meta name="keywords" content="Design Digital, Lojas virtuais, Desenvolvimento de sites, Estrategia de vendas, Consultoria web, Criação de sistems" />

<?php setHeader();?>

<div id="conteudo">
    <h1 class="titulo">Opsssss. Página não encontrada!</h1>
        <div class="erro">
        	<p>Erro 404 | Desculpe, não criamos a página quem somos, para deixar o exemplo da página 404!</p>
            <img src="<?php setHome();?>/tpl/images/erro_404.jpg" alt="Erro 404" title="Opsssss. Página não encontrada!" />
        </div><!--/erro-->
</div><!--/conteudo-->