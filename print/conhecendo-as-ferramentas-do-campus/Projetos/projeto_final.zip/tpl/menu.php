<div class="line"></div><!--/line-->
    <ul class="menu"> 
        <li class="iconr"></li>                                                                  
        <li><a href="<?php setHome();?>" title="Pro Tableless - Imprimia | Início">INÍCIO</a></li><li class="disc"></li>
        <li><a href="<?php setHome();?>/pagina/quem-somos" title="Pro Tableless - Imprimia | Quem Somos">QUEM SOMOS</a></li><li class="disc"></li>
        <li><a href="<?php setHome();?>/pagina/trabalhos" title="Pro Tableless - Imprimia | Portfólio">PORTFÓLIO</a></li><li class="disc"></li>
        <li><a href="<?php setHome();?>/pagina/servicos" title="Pro Tableless - Imprimia | Serviços">SERVIÇOS</a></li><li class="disc"></li>
        <li><a href="<?php setHome();?>/pagina/expediente" title="Pro Tableless - Imprimia | Expediente">EXPEDIENTE</a></li><li class="disc"></li>
        <li><a href="<?php setHome();?>/pagina/contato" title="Pro Tableless - Imprimia | Fale Conosco">FALE CONOSCO</a></li>
        <li class="iconl"></li> 
</ul><!--/menu-->