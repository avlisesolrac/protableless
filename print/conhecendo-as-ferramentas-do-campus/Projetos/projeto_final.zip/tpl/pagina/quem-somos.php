<title>Quem Somos | Pro Tableless - Agência web</title>
<meta name="description" content="Quem Somos | Pro Tableless - Desenvolvimento de sites nos padrões web, Trabalhando para você conquistar novos clientes" />
<meta name="keywords" content="Design Digital, Lojas virtuais, Desenvolvimento de sites, Estrategia de vendas, Consultoria web, Criação de sistems" />

<?php setHeader();?>

<div id="conteudo">
    <h1 class="titulo">Quem Somos</h1>
        <div id="pagina">
        
        	<ul class="left">
				<li>
                    <h2>FOCO EM VOCÊ E SEUS CLIENTES</h2>
                    <p>A Pro Tableless trabalha com desenvolvimento de sites com foco em seu negocio, utilizando das tecnologias mais avançadas e das 
                    tendências mais atuais para ampliar a cobertura de sua empresa na internet.</p>
                    
                    <p>As praticas de desenvolvimento limpo, otimização e utilização de web 2.0 aumentam consideravelmente suas visitas, 
                    essas que são convertidas em faturamento, mais renda, clientes e negócios serão concluídos em sua empresa!</p>
                    
                    <p>Não prestamos apenas o desenvolvimento, vamos da consultoria, projeto, publico alvo até o desenvolvimento final.</p>
                    
                    <p>Em nossa área de criação seu objetivo com o site é seguido à risca, quer ganhar dinheiro com seu negocio na internet? 
                    Ou precisa de mais clientes. A UpInside tem diversas ferramentas e estratégias de criação com resultados efetivos com 
                    foco no que você precisa!</p>
                </li>
                
                <li>
                    <h2>Trabalhando com seguimentos mundiais</h2>
                    <p>A tempos um site deixou de ser apenas um luxo a mais para sua empresa, hoje em dia sites são tão essenciais como o próprio 
                    numero de telefone da sua empresa em um guia, ou uma propaganda feita por meios de comunicação.</p>
                    
                    <p>Contudo o site faz mais que qualquer carro de divulgação no mercado, pois você pode divulgar sua empresa por completo, 
                    cada vez mais as lojas, escolas, e comércios se tornam online.</p>
                    
                    <p>Com nossas técnicas de otimização sua empresa será facilmente encontrada por pesquisas nos principais mecanismos de 
                    pesquisa da web (Google, Yahoo, Bing, Etc.) tendo sua cobertura ampliada em pouco tempo para área nacional.</p>
                    
                    <p>Trabalhamos com resultados efetivos fazendo você ganhar mais DINHEIRO e CLIENTES, ampliando seu negocio com resultados 
                    seguimentados em seu produto ou serviço.</p>
                </li>
                
                <li>
                    <h2>ferramentas exclusivas</h2>
                    <p>Nossos sistemas são desenvolvidos exclusivamente para nossos clientes, e nos preocupamos com seu tempo. 
                    Por esse motivo temos um painel de gerenciamento próprio para a alimentação diária de seu site!</p>
                    
                    <p>Dispensando qualquer conhecimento em programação nosso painel tem todas as ferramentas necessária para que você poste seus 
                    produtos, novidades, serviços, etc.</p>
                    
                    <p>O painel tem atividades automatizadas que aplicam técnicas de divulgação em redes sociais, sistemas de assinaturas e 
                    atualização dos mecanismos de busca, sendo assim você só tem de publicar seu conteúdo em seu site, e nosso painel avisa 
                    os buscadores que seu produto foi publicado!</p>
                    
                    <p><strong>Agilidade, flexibilidade e resultado!</strong></p>
                </li>   
            </ul><!--/left-->
           
           <ul class="right">
           		<li><img src="<?php setHome();?>/tpl/midias/emp_art1.png" align="Quem Somos | Projetos" title="Projeto, Design, Execução" /></li>
                <li><img src="<?php setHome();?>/tpl/midias/emp_art2.png" align="Quem Somos | SEO" title="Otimização de sites, SEO" /></li>
                <li><img src="<?php setHome();?>/tpl/midias/emp_art3.png" align="Quem Somos | Ferramentas" title="Ferramentas exclusivas, Soluções" /></li>
           </ul><!--/right-->
           
        </div><!--/pagina-->
</div><!--/conteudo-->