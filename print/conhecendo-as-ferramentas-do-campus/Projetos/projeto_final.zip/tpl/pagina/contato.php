<title>Fale Conosco | Pro Tableless - Agência web</title>
<meta name="description" content="Fale Conosco | Pro Tableless - Desenvolvimento de sites nos padrões web, Trabalhando para você conquistar novos clientes" />
<meta name="keywords" content="Design Digital, Lojas virtuais, Desenvolvimento de sites, Estrategia de vendas, Consultoria web, Criação de sistems" />

<?php setHeader();?>

<div id="conteudo">
    <h1 class="titulo">Fale Conosco</h1>
        <div id="pagina"> 
        
        	<div class="contato">
            	<h3>Por Telefone:</h3>
                    <p>(54) 3381.2185</p>
                    <p>(54) 3381.2185</p>
                    
                <h3>Por E-mail</h3>
                	<p>contato@upinside.com.br</p>            
            </div><!--contato-->
            
            
            <form class="fale" action="" method="post">
            	<label>
                	<span>Nome:</span>
                    <input type="text" name="nome" />
                </label>
                <label>
                	<span>E-mail:</span>
                    <input type="text" name="email" />
                </label>
                <label>
                	<span>Telefone:</span>
                    <input type="text" name="nome" id="fone" />
                </label>
                <label>
                	<span>Mensagem:</span>
                    <textarea name="msg" rows="8"></textarea>
                </label>
                <input type="submit" name="enviar" value="Entre em Contato" class="btn" /> 
            </form>
              
        </div><!--/pagina-->
</div><!--/conteudo-->