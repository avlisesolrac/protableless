<title>Trabalhos | Pro Tableless - Agência web</title>
<meta name="description" content="Trabalhos | Pro Tableless - Desenvolvimento de sites nos padrões web, Trabalhando para você conquistar novos clientes" />
<meta name="keywords" content="Design Digital, Lojas virtuais, Desenvolvimento de sites, Estrategia de vendas, Consultoria web, Criação de sistems" />

<?php setHeader();?>

<div id="conteudo">
    <h1 class="titulo">Portfólio - Veja algúns trabalhos</h1>
        <div id="pagina">
        	<ul class="trabalhos">
            	<li>
                	<a href="<?php setHome();?>/tpl/midias/guarana-o.png" title="Guarana" rel="shadowbox">
                        <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/guarana.png&h=180&w=250&zc=1&q=100"
                         alt="Trabalho Guarana Antartica" title="Portfólio - Guarana Antartica"> 
                    </a>
                        <div class="link"><a target="_blank" href="http://www.guaranaantarctica.com.br/" title="Pro Tableless - Guarana Antartica">www.guaranaantarctica.com.br/</a></div><!--/link-->
                        <div class="date">02/09/2011 - Projeto, Design e Execução</div><!--/date-->
                </li>
                
            	<li>
                	<a href="<?php setHome();?>/tpl/midias/facebook-o.jpg" title="Facebook" rel="shadowbox">
                        <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/facebook.jpg&h=180&w=250&zc=1&q=100"
                         alt="Trabalho Facebook" title="Portfólio -Facebook"> 
                    </a>
                        <div class="link"><a target="_blank" href="http://www.facebook.com" title="Pro Tableless - Facebook">www.facebook.com/</a></div><!--/link-->
                        <div class="date">02/09/2011 - Projeto, Design e Execução</div><!--/date-->
                </li>
                
                <li>
                	<a href="<?php setHome();?>/tpl/midias/twitter-o.jpg" title="Twitter" rel="shadowbox">
                        <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/twitter.jpg&h=180&w=250&zc=1&q=100"
                         alt="Trabalho Twitter" title="Portfólio - Twitter"> 
                    </a>
                        <div class="link"><a target="_blank" href="http://twitter.com/" title="Pro Tableless - Twitter">www.twitter.com/</a></div><!--/link-->
                        <div class="date">02/09/2011 - Projeto, Design e Execução</div><!--/date-->
                </li>
                
                <li>
                	<a href="<?php setHome();?>/tpl/midias/upinside-o.jpg" title="UpInside" rel="shadowbox">
                        <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/upinside.png&h=180&w=250&zc=1&q=100"
                         alt="Trabalho UpInside" title="Portfólio - UpInside"> 
                    </a>
                        <div class="link"><a target="_blank" href="http://www.upinside.com" title="UpInside">www.upinside.com.br/</a></div><!--/link-->
                        <div class="date">02/09/2011 - Projeto, Design e Execução</div><!--/date-->
                </li>
                
                <li>
                	<a href="<?php setHome();?>/tpl/midias/kibon-o.jpg" title="Kibon" rel="shadowbox">
                        <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/kibon.jpg&h=180&w=250&zc=1&q=100"
                         alt="Trabalho Kibon" title="Portfólio - Kibon"> 
                    </a>
                        <div class="link"><a target="_blank" href="http://www.kibon.com.br/" title="Pro Tableless - Kibon">www.kibon.com.br/</a></div><!--/link-->
                        <div class="date">02/09/2011 - Projeto, Design e Execução</div><!--/date-->
                </li>
                
                <li>
                	<a href="<?php setHome();?>/tpl/midias/coca-o.jpg" title="Coca Cola" rel="shadowbox">
                        <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/coca.jpg&h=180&w=250&zc=1&q=100"
                         alt="Trabalho Coca Cola" title="Portfólio - Coca Cola"> 
                    </a>
                        <div class="link"><a target="_blank" href="http://www.cocacola.com.br/" title="Pro Tableless - Coca Cola">www.cocacola.com.br/</a></div><!--/link-->
                        <div class="date">02/09/2011 - Projeto, Design e Execução</div><!--/date-->
                </li>
            
            </ul><!--/trabahlos-->
        </div><!--/pagina-->
</div><!--/conteudo-->