<title>Pro Tableless - Agência web | Desenvolvimento Web</title>
<meta name="description" content="Home | Pro Tableless - Desenvolvimento de sites nos padrões web, Trabalhando para você conquistar novos clientes" />
<meta name="keywords" content="Design Digital, Lojas virtuais, Desenvolvimento de sites, Estrategia de vendas, Consultoria web, Criação de sistems" />

<?php setHeader();?>

<div id="conteudo">
    <h1 class="titulo">Serviços</h1>
    
    <div class="item_left">
        <div class="ref">
            <h2>Conheça com o que trabalhamos!</h2>

            <p>A Pro tableless trabalha no ramo de soluções web, desenvolvemos sistemas, sitesm lojas virtuais, tudo nos padrões de desenvolvimento.
            Sempre visamos seu negócio e seus cliente, e pensamos em soluções mais adequadas a você!</p>
            
            <ul>
                <li>Consultoria!</li>
                <li>Design!</li>
                <li>Execução!</li>
                <li>Configuração!</li>
            </ul>
            
            <p>Tudo está incluso em nossos serviços. você recebe seu site hospedado, configurado, otimizado e com tudo funcionando!</p>
            
            <p>E ainda conta com um suporte exepcional para suas dúvidas do dia a dia!.</p>
            
            <span>Venha para a Pro Tableless!</span>
            
            <div class="contato">
                <span>Entre em contato:</span>
                <p>Teleone: (54) 3381.2185 / Celular: (54) 3381.2185</p>
                <p>E-mail: contato@upinside.com.br</p>
            </div><!--/contento-->
            
        </div><!--/ref-->
        
        <ul class="images">
            <li><img src="<?php setHome();?>/tpl/midias/01.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li>
            <li><img src="<?php setHome();?>/tpl/midias/02.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li>
        </ul>
        
        
    </div><!--/item_left-->
    
    <div class="item_right">
            <div class="thumb"><img src="<?php setHome();?>/tpl/midias/03.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></div><!--/thumb-->
            
            <ul class="gallery">
                <li>DESIGN DIGITAL</li>
                <li>OTIMIZAÇÃO DE SITES SEO</li>  
                <li>CRIAÇÃO DE TEMAS PARA CMS's</li>  
                <li>DESENVOLVIMENTO DE WEBSITES</li> 
                <li>LOJAS VIRTUAIS, E-COMMERCE</li> 
                <li>CONSULTORIA EM PUBLICIDADE ONLINE</li>
                <li>DESENVOLVIMENTO DE SISTEMAS WEB</li>
                <li>FERRAMENTAS EXCLUSIVAS PARA VOCÊ</li>                  
            </ul><!--/gallery-->
            
</div><!--/item_right-->
</div><!--/conteudo-->



















