<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pro Tableless - Imprima</title>
<meta name="description" content="Descrição" />
<meta name="keywords" content="Palavras Chave" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>


<style type="text/css" media="print">
#header .menu, #footer .menu{display:none;}
#conteudo .print{display:none;}
#header .info_print{display:block; text-align:center; margin:5px 0;}
#conteudo .titulo{margin-bottom:5px; padding-bottom:5px; border-bottom:5px solid #999;}
#footer{margin-top:5px; padding-top:5px; border-top:5px solid #999;}
</style>

<body>
<div id="site">

	<div id="header">
    	<div class="logo">
        	<a href="index.php" title="Pro Tableless - Imprimia | Home">
            	<img src="images/logo.png" border="0" alt="Logo" title="Pro Tableless, Imprima o Anúncio" width="480" height="109" />
            </a>
        </div><!--/logo-->
        <div class="info_print">Anúncio impresso do site www.campusup.com.br/curso/curso-pro-tableless</div>
        <div class="line"></div><!--/line-->
        	<ul class="menu"> 
            	<li class="iconr"></li>                                                                  
                <li><a href="#" title="Pro Tableless - Imprimia | Início">INÍCIO</a></li><li class="disc"></li>
            	<li><a href="#" title="Pro Tableless - Imprimia | Quem Somos">QUEM SOMOS</a></li><li class="disc"></li>
                <li><a href="#" title="Pro Tableless - Imprimia | Portfólio">PORTFÓLIO</a></li><li class="disc"></li>
                <li><a href="#" title="Pro Tableless - Imprimia | Serviços">SERVIÇOS</a></li><li class="disc"></li>
                <li><a href="#" title="Pro Tableless - Imprimia | Expediente">EXPEDIENTE</a></li><li class="disc"></li>
                <li><a href="#" title="Pro Tableless - Imprimia | Fale Conosco">FALE CONOSCO</a></li>
                <li class="iconl"></li> 
            </ul><!--/menu-->
    </div><!--/header-->
    <div id="spacer"></div><!--/spacer-->
    
    <div id="content">
    	<div id="conteudo">
        	<h1 class="titulo">PRO TABLESS - Anúncio de sofa</h1>
            
            <div class="item_left">
          		<div class="ref">
					<h2>Estofado carmo Ref:1058</h2>

                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                     when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                    
                    <ul>
                        <li>Lorem Ipsum is simply</li>
                        <li>ever since the 1500s</li>
                        <li>printing and typesetting</li>
                    </ul>
                    
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    
                    <span>R$: 2.490,00</span>
                    
                    <div class="contato">
                    	<span>Entre em contato:</span>
                        <p>Teleone: (54) 3381.2185 / Celular: (54) 3381.2185</p>
                        <p>E-mail: contato@upinside.com.br</p>
                    </div><!--/contento-->
                    
                </div><!--/ref-->
                
                <ul class="images">
                	<li><img src="midias/01.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li>
                    <li><img src="midias/02.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li>
                </ul>
                
                
            </div><!--/item_left-->
            
            <div class="item_right">
            		<div class="thumb"><img src="midias/03.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></div><!--/thumb-->
                    
                    <ul class="gallery">
                    	<li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li>
                        <li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li> 
                        <li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li> 
                        <li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li> 
                        <li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li> 
                        <li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li> 
                        <li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li> 
                        <li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li> 
                        <li><img src="midias/04.png" alt="Imagem do anúncio" title="Sofa Ref:Ref:1058" /></li>                     
                    </ul><!--/gallery-->
                    
                    
                    	<div class="print"><a href="javascript:self.print()">CLIQUE AQUI PAR IMPRIMIR ESTE ANÚNCIO</a></div>
                    
            </div><!--/item_right-->
            
        </div><!--/conteudo-->
    </div><!--/content-->

<div id="clear"></div><!--clear-->
</div><!--/site-->

<div id="footer">
	<div class="footer_content">
    	<div id="footer_spacer"></div><!--/footer_spacer-->
			<div class="line"></div><!--/line-->
        	<ul class="menu"> 
            	<li class="iconr"></li>                                                                  
                <li><a href="#" title="Pro Tableless - Imprimia | Início">INÍCIO</a></li><li class="disc"></li>
            	<li><a href="#" title="Pro Tableless - Imprimia | Quem Somos">QUEM SOMOS</a></li><li class="disc"></li>
                <li><a href="#" title="Pro Tableless - Imprimia | Portfólio">PORTFÓLIO</a></li><li class="disc"></li>
                <li><a href="#" title="Pro Tableless - Imprimia | Serviços">SERVIÇOS</a></li><li class="disc"></li>
                <li><a href="#" title="Pro Tableless - Imprimia | Expediente">EXPEDIENTE</a></li><li class="disc"></li>
                <li><a href="#" title="Pro Tableless - Imprimia | Fale Conosco">FALE CONOSCO</a></li>
                <li class="iconl"></li> 
            </ul><!--/menu-->
    
    		<ul class="footer_elementos">
            	<li>
                	<img src="images/logo_footer.png" border="0" alt="Logo" title="Pro Tableless - Imprima"/>
                </li>
                <li>
                	<div class="tel">Ligue:</div><!--/tel-->
                    <p>(54) 3381-2185</p>
                    <p>(54) 8408-3448</p>
                </li>
                <li class="right">
                	<div class="mail">Escreva:</div>
                    <p class="min">contato@protableless.com.br</p>
                    <p class="min">falecom@protableless.com.br</p>                    
                </li>
            </ul>
    
    </div><!--/content-->
</div><!--/footer-->

</body>
</html>

























